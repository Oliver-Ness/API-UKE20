
const mybtn = document.getElementById('myList');
const tre = document.getElementById('btn');
tre.addEventListener("click", openmenu );
function openmenu() {
    if(mybtn.style.display != 'block') {
        mybtn.style.display = 'block';
    } else {
        mybtn.style.display = 'none';
    }
    console.log('clicked');
}




// Dette er bare instillingene til kartet her kan man endre ting som for eksempel hvilket type kart
const attribution = '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'

var map = L.map('map1')
let marker = L.marker([59.745164250056135,10.164131070531106 ]).addTo(map)
let tileURL =   L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { }).addTo(map);
const tiles =L.tileLayer(tileURL,{attribution})






// Dette er for Stat knappen, sånn at alle de andre knappene kommer opp
function ShowStates(){

    var elements = document.getElementsByClassName('sg')
    for (var i = 0; i < elements.length; i++) {
        if (elements[i].style.display === 'none' || elements[i].style.display === '') {
            elements[i].style.display = 'block';
        } else {
            elements[i].style.display = 'none';
        

}
    }
}

async function show_me(State){
    let lat;
    let long;
    


    let place = State;
    // I linjen under så fetcher jeg informasjonen fra lenken og legger på place variablen som blir valgt når du trykker på en av knappene
    let resp = await fetch('https://api.openbrewerydb.org/v1/breweries?by_city=' + place);
    let mydata = await resp.json();
    console.log(mydata);
    // Under her så skjer ting som at vi flytter kart kameraet og fjerner de andre pinnene hvis det var noen
    if (mydata[0].latitude && mydata[0].longitude) {
        lat = mydata[0].latitude;
        long = mydata[0].longitude;
        map.setView([lat,long], 13);
    } else {
        map.setView([0,0], 2);
    }

    map.eachLayer(function(layer) {
        if (layer instanceof L.Marker) {
            map.removeLayer(layer);
        }
    });


    //Koden under er for å legge til pinnene og alle detaljene om bryggeriet som da inkluderer en nettside hvis de har en.
    mydata.forEach(element => {
        if (element.latitude && element.longitude) {
            let popupContent = `<b>${element.name}</b><br>${element.street}<br>${element.city}, ${element.state}`;
            if (element.website_url) {
                popupContent += `<br><a href="${element.website_url}" target="_blank">Website</a>`;
            }

            let marker = L.marker([element.latitude, element.longitude]).addTo(map);
            marker.bindPopup(popupContent);
        }
    });
    

}




